CREATE INDEX HorsePositionTester
ON HorseRaceResults(horseID, finishPosition);
