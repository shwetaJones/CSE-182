CREATE INDEX LookUpShowings 
  ON Showings(showingDate, startTime);